import { ThemeService } from '../../services/ThemeService';
import { AuthController } from '../../controllers/authController';
import { StorageService } from '../../services/StorageService';
import { User } from '../../types';

// Define custom event types
interface ProfileUpdatedEvent extends CustomEvent {
  detail: {
    username: string;
  };
}

export class Header {
  private element: HTMLElement;
  private authController: AuthController;
  private themeService: ThemeService;
  private storageService: StorageService;
  private userNameElement: HTMLElement | null = null;

  constructor(private onLogout: () => void, private onThemeToggle: () => void) {
    this.authController = new AuthController();
    this.themeService = ThemeService.getInstance();
    this.storageService = StorageService.getInstance();
    this.element = this.createHeader();
    
    // Listen for storage changes to update user info
    this.setupStorageListener();
  }

  private createHeader(): HTMLElement {
    const header = document.createElement('header');
    header.className = 'app-header';

    // Logo/Title
    const logoContainer = document.createElement('div');
    logoContainer.className = 'logo-container';

    const logo = document.createElement('h1');
    logo.textContent = 'Task Manager';
    logo.className = 'app-logo';

    logoContainer.appendChild(logo);

    // Navigation
    const nav = document.createElement('nav');
    nav.className = 'main-nav';

    const navList = document.createElement('ul');
    navList.className = 'nav-list';

    const navItems = [
      { text: 'Dashboard', id: 'dashboard', icon: 'fas fa-chart-bar' },
      { text: 'Tasks', id: 'tasks', icon: 'fas fa-tasks' },
      { text: 'Categories', id: 'categories', icon: 'fas fa-folder' },
      { text: 'Profile', id: 'profile', icon: 'fas fa-user' }
    ];

    navItems.forEach(item => {
      const li = document.createElement('li');
      li.className = 'nav-item';

      const button = document.createElement('button');
      button.className = 'nav-link';
      button.dataset.page = item.id;
      
      // Create icon element
      const icon = document.createElement('i');
      icon.className = item.icon;
      
      // Create text span
      const text = document.createElement('span');
      text.textContent = ` ${item.text}`;
      
      // Append icon and text
      button.appendChild(icon);
      button.appendChild(text);

      li.appendChild(button);
      navList.appendChild(li);
    });

    nav.appendChild(navList);

    // User controls
    const controls = document.createElement('div');
    controls.className = 'header-controls';

    // Theme toggle
    const themeToggle = document.createElement('button');
    themeToggle.className = 'btn-icon theme-toggle';
    
    // Theme icon - using both moon and sun icons
    const themeIcon = document.createElement('i');
    themeIcon.className = 'fas fa-moon';
    themeToggle.appendChild(themeIcon);
    
    themeToggle.title = 'Toggle theme';
    themeToggle.addEventListener('click', () => {
      this.themeService.toggleTheme();
      this.onThemeToggle();
      // Update icon based on theme
      const isDark = document.body.classList.contains('dark-theme');
      themeIcon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
    });

    // User menu
    const userMenu = document.createElement('div');
    userMenu.className = 'user-menu';

    // Get current user - try from storage first, then auth controller
    const currentUser = this.getCurrentUser();
    
    if (currentUser) {
      const userAvatar = document.createElement('div');
      userAvatar.className = 'user-avatar';
      
      // Try to load avatar from storage
      this.loadUserAvatar(userAvatar);

      this.userNameElement = document.createElement('span');
      this.userNameElement.className = 'user-name';
      this.userNameElement.textContent = currentUser.username;

      const logoutBtn = document.createElement('button');
      logoutBtn.className = 'btn-text logout-btn';
      
      // Add logout icon
      const logoutIcon = document.createElement('i');
      logoutIcon.className = 'fas fa-sign-out-alt';
      logoutBtn.appendChild(logoutIcon);
      
      const logoutText = document.createElement('span');
      logoutText.textContent = ' Logout';
      logoutBtn.appendChild(logoutText);
      
      logoutBtn.addEventListener('click', this.onLogout);

      userMenu.appendChild(userAvatar);
      userMenu.appendChild(this.userNameElement);
      userMenu.appendChild(logoutBtn);
    }

    controls.appendChild(themeToggle);
    controls.appendChild(userMenu);

    // Mobile menu toggle
    const mobileToggle = document.createElement('button');
    mobileToggle.className = 'mobile-menu-toggle';
    
    const menuIcon = document.createElement('i');
    menuIcon.className = 'fas fa-bars';
    mobileToggle.appendChild(menuIcon);
    
    mobileToggle.addEventListener('click', () => {
      nav.classList.toggle('mobile-open');
      // Toggle between bars and times icon
      menuIcon.className = nav.classList.contains('mobile-open') 
        ? 'fas fa-times' 
        : 'fas fa-bars';
    });

    // Assemble header
    header.appendChild(logoContainer);
    header.appendChild(nav);
    header.appendChild(controls);
    header.appendChild(mobileToggle);

    return header;
  }

  private async loadUserAvatar(avatarElement: HTMLElement): Promise<void> {
    try {
      const avatarUrl = await this.storageService.get<string>('user_avatar');
      if (avatarUrl) {
        // Use the uploaded avatar
        avatarElement.style.backgroundImage = `url(${avatarUrl})`;
        avatarElement.style.backgroundSize = 'cover';
        avatarElement.style.backgroundPosition = 'center';
        avatarElement.innerHTML = '';
      } else {
        // Use default Font Awesome icon
        const avatarIcon = document.createElement('i');
        avatarIcon.className = 'fas fa-user-circle';
        avatarElement.appendChild(avatarIcon);
      }
    } catch (error) {
      console.error('Failed to load avatar:', error);
      const avatarIcon = document.createElement('i');
      avatarIcon.className = 'fas fa-user-circle';
      avatarElement.appendChild(avatarIcon);
    }
  }

  private getCurrentUser(): User | null {
    try {
      // First try to get from localStorage directly for immediate access
      const storedUserStr = localStorage.getItem('current_user');
      if (storedUserStr) {
        return JSON.parse(storedUserStr) as User;
      }
      
      // Fall back to AuthController
      return this.authController.getCurrentUser();
    } catch (error) {
      console.error('Failed to get current user:', error);
      return this.authController.getCurrentUser();
    }
  }

  private setupStorageListener(): void {
    // Listen for storage changes to update user info in real-time
    window.addEventListener('storage', (event: StorageEvent) => {
      if (event.key === 'current_user' && event.newValue) {
        try {
          const user = JSON.parse(event.newValue) as User;
          this.updateUserName(user.username);
        } catch (error) {
          console.error('Failed to parse user data from storage event:', error);
        }
      }
      
      if (event.key === 'user_avatar') {
        this.updateUserAvatar();
      }
    });
    
    // Also listen for custom events that can be dispatched from ProfilePage
    window.addEventListener('profile-updated', ((event: ProfileUpdatedEvent) => {
      if (event.detail && event.detail.username) {
        this.updateUserName(event.detail.username);
      }
    }) as EventListener);
    
    window.addEventListener('avatar-updated', (() => {
      this.updateUserAvatar();
    }) as EventListener);
  }

  public updateUserName(username: string): void {
    if (this.userNameElement) {
      this.userNameElement.textContent = username;
    } else {
      // If userNameElement doesn't exist yet, try to find it
      const userNameEl = this.element.querySelector('.user-name');
      if (userNameEl) {
        userNameEl.textContent = username;
        this.userNameElement = userNameEl as HTMLElement;
      }
    }
  }

  public updateUserAvatar(): void {
    const avatarElement = this.element.querySelector('.user-avatar');
    if (avatarElement) {
      this.loadUserAvatar(avatarElement as HTMLElement);
    }
  }

  public updateUserInfo(): void {
    const userMenu = this.element.querySelector('.user-menu');
    if (userMenu) {
      userMenu.innerHTML = '';
      
      const currentUser = this.getCurrentUser();
      if (currentUser) {
        const userAvatar = document.createElement('div');
        userAvatar.className = 'user-avatar';
        
        // Load avatar from storage
        this.loadUserAvatar(userAvatar);

        this.userNameElement = document.createElement('span');
        this.userNameElement.className = 'user-name';
        this.userNameElement.textContent = currentUser.username;

        const logoutBtn = document.createElement('button');
        logoutBtn.className = 'btn-text logout-btn';
        
        const logoutIcon = document.createElement('i');
        logoutIcon.className = 'fas fa-sign-out-alt';
        logoutBtn.appendChild(logoutIcon);
        
        const logoutText = document.createElement('span');
        logoutText.textContent = ' Logout';
        logoutBtn.appendChild(logoutText);
        
        logoutBtn.addEventListener('click', this.onLogout);

        userMenu.appendChild(userAvatar);
        userMenu.appendChild(this.userNameElement);
        userMenu.appendChild(logoutBtn);
      }
    }
  }

  setActivePage(pageId: string): void {
    const navLinks = this.element.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      if (link instanceof HTMLElement) {
        link.classList.toggle('active', link.dataset.page === pageId);
      }
    });
  }

  render(): HTMLElement {
    return this.element;
  }
}