import { StorageService } from './StorageService';

export class AvatarService {
  private static instance: AvatarService;
  private subscribers: ((avatarUrl: string | null) => void)[] = [];

  private constructor() {}

  static getInstance(): AvatarService {
    if (!AvatarService.instance) {
      AvatarService.instance = new AvatarService();
    }
    return AvatarService.instance;
  }

  async getAvatar(): Promise<string | null> {
    const storageService = StorageService.getInstance();
    return await storageService.get<string>('user_avatar');
  }

  async setAvatar(avatarUrl: string): Promise<void> {
    const storageService = StorageService.getInstance();
    await storageService.save('user_avatar', avatarUrl);
    localStorage.setItem('user_avatar', avatarUrl);
    
    // Notify all subscribers
    this.notifySubscribers(avatarUrl);
  }

  async removeAvatar(): Promise<void> {
    const storageService = StorageService.getInstance();
    await storageService.remove('user_avatar');
    localStorage.removeItem('user_avatar');
    
    // Notify all subscribers
    this.notifySubscribers(null);
  }

  subscribe(callback: (avatarUrl: string | null) => void): void {
    this.subscribers.push(callback);
  }

  unsubscribe(callback: (avatarUrl: string | null) => void): void {
    this.subscribers = this.subscribers.filter(sub => sub !== callback);
  }

  private notifySubscribers(avatarUrl: string | null): void {
    this.subscribers.forEach(callback => callback(avatarUrl));
  }
}